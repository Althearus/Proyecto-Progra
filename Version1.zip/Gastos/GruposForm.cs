﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

public class GruposForm : Form
{
    private ListBox lstGrupos;
    private TextBox txtNuevoGrupo;
    private Button btnAgregarGrupo;
    private ListBox lstMiembrosDisponibles;
    private ListBox lstMiembrosSeleccionados;
    private Button btnAgregarMiembro;
    private Button btnQuitarMiembro;

    private List<Grupo> grupos;
    private List<Usuario> usuarios;

    public GruposForm(List<Grupo> grupos, List<Usuario> usuarios)
    {
        this.grupos = grupos;
        this.usuarios = usuarios;

        this.Text = "Grupos";
        this.Width = 700;
        this.Height = 450;

        lstGrupos = new ListBox { Left = 10, Top = 10, Width = 280, Height = 300 };
        txtNuevoGrupo = new TextBox { Left = 10, Top = 320, Width = 200 };
        btnAgregarGrupo = new Button { Text = "Agregar Grupo", Left = 220, Top = 318, Width = 70 };

        lstMiembrosDisponibles = new ListBox { Left = 300, Top = 10, Width = 160, Height = 200 };
        lstMiembrosSeleccionados = new ListBox { Left = 510, Top = 10, Width = 160, Height = 200 };

        btnAgregarMiembro = new Button { Text = ">>", Left = 470, Top = 80, Width = 30 };
        btnQuitarMiembro = new Button { Text = "<<", Left = 470, Top = 120, Width = 30 };

        btnAgregarGrupo.Click += BtnAgregarGrupo_Click;
        btnAgregarMiembro.Click += BtnAgregarMiembro_Click;
        btnQuitarMiembro.Click += BtnQuitarMiembro_Click;

        this.Controls.Add(lstGrupos);
        this.Controls.Add(txtNuevoGrupo);
        this.Controls.Add(btnAgregarGrupo);
        this.Controls.Add(lstMiembrosDisponibles);
        this.Controls.Add(lstMiembrosSeleccionados);
        this.Controls.Add(btnAgregarMiembro);
        this.Controls.Add(btnQuitarMiembro);

        CargarGrupos();
        CargarUsuariosDisponibles();
    }

    private void CargarGrupos()
    {
        lstGrupos.Items.Clear();
        foreach (var g in grupos)
        {
            lstGrupos.Items.Add($"{g.Nombre} ({g.Miembros?.Count ?? 0} miembros)");
        }
    }

    private void CargarUsuariosDisponibles()
    {
        lstMiembrosDisponibles.Items.Clear();
        foreach (var u in usuarios)
        {
            lstMiembrosDisponibles.Items.Add(u.Nombre);
        }
        lstMiembrosSeleccionados.Items.Clear();
    }

    private void BtnAgregarGrupo_Click(object sender, System.EventArgs e)
    {
        string nombreGrupo = txtNuevoGrupo.Text.Trim();
        if (!string.IsNullOrEmpty(nombreGrupo))
        {
            var nuevoGrupo = new Grupo
            {
                Id = System.Guid.NewGuid().ToString(),
                Nombre = nombreGrupo,
                Imagen = "", // Aquí podrías agregar funcionalidad para cargar imagen
                Miembros = new List<string>()
            };
            grupos.Add(nuevoGrupo);
            txtNuevoGrupo.Clear();
            CargarGrupos();
            MessageBox.Show("Grupo creado. Ahora seleccione miembros.");
        }
        else
        {
            MessageBox.Show("Ingrese un nombre válido para el grupo.");
        }
    }

    private void BtnAgregarMiembro_Click(object sender, System.EventArgs e)
    {
        if (lstMiembrosDisponibles.SelectedItem != null)
        {
            var nombre = lstMiembrosDisponibles.SelectedItem.ToString();
            lstMiembrosSeleccionados.Items.Add(nombre);
            lstMiembrosDisponibles.Items.Remove(nombre);
        }
    }

    private void BtnQuitarMiembro_Click(object sender, System.EventArgs e)
    {
        if (lstMiembrosSeleccionados.SelectedItem != null)
        {
            var nombre = lstMiembrosSeleccionados.SelectedItem.ToString();
            lstMiembrosDisponibles.Items.Add(nombre);
            lstMiembrosSeleccionados.Items.Remove(nombre);
        }
    }
}