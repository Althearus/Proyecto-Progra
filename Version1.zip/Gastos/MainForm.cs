﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Gastos.Models;

namespace Gastos
{
    public class MainForm : Form
    {
        private List<Usuario> usuarios;
        private List<Grupo> grupos;
        private List<Gasto> gastos;
        private GastoController gastoController;

        // Controles manuales
        private Button btnCargarDatos;
        private Button btnMostrarBalance;
        private Button btnUsuarios;
        private Button btnGrupos;
        private Button btnGastos;
        private Button btnReportes;
        private ListBox lstBalances;

        public MainForm()
        {
            InicializarComponentes();
        }

        private void InicializarComponentes()
        {
            this.Text = "Gestión de Gastos Compartidos";
            this.Width = 500;
            this.Height = 480;

            // Botones y ListBox
            btnCargarDatos = new Button { Text = "Cargar Datos", Left = 10, Top = 10, Width = 100 };
            btnMostrarBalance = new Button { Text = "Mostrar Balance", Left = 120, Top = 10, Width = 120 };
            btnUsuarios = new Button { Text = "Ver Usuarios", Left = 10, Top = 370, Width = 100 };
            btnGrupos = new Button { Text = "Ver Grupos", Left = 120, Top = 370, Width = 100 };
            btnGastos = new Button { Text = "Ver Gastos", Left = 230, Top = 370, Width = 100 };
            btnReportes = new Button { Text = "Reportes", Left = 340, Top = 370, Width = 100 };
            lstBalances = new ListBox { Left = 10, Top = 50, Width = 460, Height = 300 };

            // Agregar al formulario
            this.Controls.Add(btnCargarDatos);
            this.Controls.Add(btnMostrarBalance);
            this.Controls.Add(btnUsuarios);
            this.Controls.Add(btnGrupos);
            this.Controls.Add(btnGastos);
            this.Controls.Add(btnReportes);
            this.Controls.Add(lstBalances);

            // Asignar eventos
            btnCargarDatos.Click += btnCargarDatos_Click;
            btnMostrarBalance.Click += btnMostrarBalance_Click;
            btnUsuarios.Click += (s, e) => new UsuariosForm(usuarios).Show();
            btnGrupos.Click += (s, e) => new GruposForm(grupos, usuarios).Show();
            btnGastos.Click += (s, e) => new GastosForm(gastos).Show();
            btnReportes.Click += (s, e) => new ReportesForm(gastoController).Show();
        }

        private void btnCargarDatos_Click(object sender, EventArgs e)
        {
            usuarios = DataLoader.CargarUsuariosDesdeJson("Data\\usuarios.json");
            grupos = DataLoader.CargarGruposDesdeJson("Data\\grupos.json");
            gastos = DataLoader.CargarGastosDesdeCsv("Data\\gastos.csv");

            gastoController = new GastoController(gastos);
            MessageBox.Show("Datos cargados correctamente.");
        }

        private void btnMostrarBalance_Click(object sender, EventArgs e)
        {
            if (usuarios != null && gastoController != null)
            {
                lstBalances.Items.Clear();
                foreach (var usuario in usuarios)
                {
                    decimal balance = gastoController.CalcularBalanceUsuario(usuario.Id);
                    lstBalances.Items.Add($"{usuario.Nombre}: ₡{balance:N2}");
                }
            }
        }
    }
}