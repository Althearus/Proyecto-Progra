﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Gastos.Models;
    public partial class GastosForm : Form
    {
        private List<Gasto> gastos;
        private ListView listView;

        public GastosForm(List<Gasto> gastos)
        {
            this.gastos = gastos;
            InitializeComponent();
            CargarGastos();
        }

        private void InitializeComponent()
        {
            this.Text = "Lista de Gastos";
            this.Width = 800;
            this.Height = 500;

            listView = new ListView
            {
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                Width = 760,
                Height = 400,
                Location = new Point(10, 10)
            };

            listView.Columns.Add("Nombre", 120);
            listView.Columns.Add("Descripción", 180);
            listView.Columns.Add("Fecha", 100);
            listView.Columns.Add("Monto", 80);
            listView.Columns.Add("Pagado Por", 100);
            listView.Columns.Add("Incluye A", 160);

            this.Controls.Add(listView);
        }

        private void CargarGastos()
        {
            listView.Items.Clear();

            foreach (var gasto in gastos)
            {
                var incluyeA = string.Join(", ", gasto.IncluyeA);

                var item = new ListViewItem(new[]
                {
                    gasto.Nombre,
                    gasto.Descripcion,
                    gasto.Fecha.ToShortDateString(),
                    "₡" + gasto.Monto.ToString("N2"),
                    gasto.PagadoPor,
                    incluyeA
                });

                listView.Items.Add(item);
            }
        }
    }


