using System;
using System.Collections.Generic;
public class Grupo
{
    public string Id { get; set; }
    public string Nombre { get; set; }
    public string Imagen { get; set; }
    public List<string> Miembros { get; set; }
}