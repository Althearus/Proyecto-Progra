﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Gastos.Models;

public partial class GastosForm : Form
{
    private List<Gasto> gastos;
    private ListView listView;

    // Controles para agregar gasto nuevo
    private TextBox txtNombre;
    private TextBox txtDescripcion;
    private DateTimePicker dtpFecha;
    private TextBox txtMonto;
    private TextBox txtPagadoPor;
    private TextBox txtIncluyeA;
    private Button btnAgregarGasto;

    public GastosForm(List<Gasto> gastos)
    {
        this.gastos = gastos;
        InitializeComponent();
        CargarGastos();
    }

    private void InitializeComponent()
    {
        this.Text = "Lista de Gastos";
        this.Width = 800;
        this.Height = 600;

        listView = new ListView
        {
            View = View.Details,
            FullRowSelect = true,
            GridLines = true,
            Width = 760,
            Height = 350,
            Location = new Point(10, 10)
        };

        listView.Columns.Add("Nombre", 120);
        listView.Columns.Add("Descripción", 180);
        listView.Columns.Add("Fecha", 100);
        listView.Columns.Add("Monto", 80);
        listView.Columns.Add("Pagado Por", 100);
        listView.Columns.Add("Incluye A", 160);

        // Crear controles para nuevo gasto
        Label lblNombre = new Label { Text = "Nombre:", Location = new Point(10, 380), Width = 80 };
        txtNombre = new TextBox { Location = new Point(100, 375), Width = 200 };

        Label lblDescripcion = new Label { Text = "Descripción:", Location = new Point(10, 410), Width = 80 };
        txtDescripcion = new TextBox { Location = new Point(100, 405), Width = 200 };

        Label lblFecha = new Label { Text = "Fecha:", Location = new Point(320, 380), Width = 50 };
        dtpFecha = new DateTimePicker { Location = new Point(380, 375), Width = 150, Format = DateTimePickerFormat.Short };

        Label lblMonto = new Label { Text = "Monto:", Location = new Point(320, 410), Width = 50 };
        txtMonto = new TextBox { Location = new Point(380, 405), Width = 150 };

        Label lblPagadoPor = new Label { Text = "Pagado Por (Id):", Location = new Point(10, 440), Width = 100 };
        txtPagadoPor = new TextBox { Location = new Point(120, 435), Width = 180 };

        Label lblIncluyeA = new Label { Text = "Incluye A (Ids separados por '|'):", Location = new Point(10, 470), Width = 220 };
        txtIncluyeA = new TextBox { Location = new Point(240, 465), Width = 300 };

        btnAgregarGasto = new Button { Text = "Agregar Gasto", Location = new Point(560, 440), Width = 120, Height = 50 };
        btnAgregarGasto.Click += BtnAgregarGasto_Click;

        // Agregar controles al formulario
        this.Controls.Add(listView);
        this.Controls.Add(lblNombre);
        this.Controls.Add(txtNombre);
        this.Controls.Add(lblDescripcion);
        this.Controls.Add(txtDescripcion);
        this.Controls.Add(lblFecha);
        this.Controls.Add(dtpFecha);
        this.Controls.Add(lblMonto);
        this.Controls.Add(txtMonto);
        this.Controls.Add(lblPagadoPor);
        this.Controls.Add(txtPagadoPor);
        this.Controls.Add(lblIncluyeA);
        this.Controls.Add(txtIncluyeA);
        this.Controls.Add(btnAgregarGasto);
    }

    private void CargarGastos()
    {
        listView.Items.Clear();

        foreach (var gasto in gastos)
        {
            var incluyeA = string.Join(", ", gasto.IncluyeA);

            var item = new ListViewItem(new[]
            {
                gasto.Nombre,
                gasto.Descripcion,
                gasto.Fecha.ToShortDateString(),
                "₡" + gasto.Monto.ToString("N2"),
                gasto.PagadoPor,
                incluyeA
            });

            listView.Items.Add(item);
        }
    }

    private void BtnAgregarGasto_Click(object sender, EventArgs e)
    {
        // Validar y crear nuevo gasto
        if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
            string.IsNullOrWhiteSpace(txtMonto.Text) ||
            string.IsNullOrWhiteSpace(txtPagadoPor.Text))
        {
            MessageBox.Show("Por favor, completa los campos Nombre, Monto y Pagado Por.");
            return;
        }

        if (!decimal.TryParse(txtMonto.Text, out decimal monto))
        {
            MessageBox.Show("Monto inválido.");
            return;
        }

        var nuevoGasto = new Gasto
        {
            Id = Guid.NewGuid().ToString(),
            Nombre = txtNombre.Text.Trim(),
            Descripcion = txtDescripcion.Text.Trim(),
            Fecha = dtpFecha.Value.Date,
            Monto = monto,
            PagadoPor = txtPagadoPor.Text.Trim(),
            IncluyeA = string.IsNullOrWhiteSpace(txtIncluyeA.Text) ? new List<string>() : new List<string>(txtIncluyeA.Text.Split('|'))
        };

        gastos.Add(nuevoGasto);
        CargarGastos();

        // Limpiar inputs
        txtNombre.Clear();
        txtDescripcion.Clear();
        txtMonto.Clear();
        txtPagadoPor.Clear();
        txtIncluyeA.Clear();

        MessageBox.Show("Gasto agregado correctamente.");
    }
}




