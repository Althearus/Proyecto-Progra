using System;
using System.Collections.Generic;
using System.Linq;
using Gastos.Models;
public class GastoController
{
    private List<Gasto> gastos;

    public GastoController(List<Gasto> gastos)
    {
        this.gastos = gastos;
    }

    public List<Gasto> ObtenerTodos() => gastos;

    public List<Gasto> ObtenerPorFecha(DateTime desde, DateTime hasta)
    {
        return gastos.Where(g => g.Fecha >= desde && g.Fecha <= hasta).ToList();
    }

    public decimal CalcularBalanceUsuario(string usuarioId)
    {
        decimal totalPagado = gastos
            .Where(g => g.PagadoPor == usuarioId)
            .Sum(g => g.Monto);

        decimal totalDeuda = gastos
            .Where(g => g.IncluyeA.Contains(usuarioId))
            .Sum(g => g.Monto / g.IncluyeA.Count);

        return totalPagado - totalDeuda;
    }
}