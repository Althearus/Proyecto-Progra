﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Gastos.Models;
using System.IO;
using Newtonsoft.Json;
using CsvHelper;
using CsvHelper.Configuration;
using System.Globalization;

namespace Gastos
{
    public class MainForm : Form
    {
        private List<Usuario> usuarios;
        private List<Grupo> grupos;
        private List<Gasto> gastos;
        private GastoController gastoController;

        // Controles manuales
        private Button btnCargarDatos;
        private Button btnMostrarBalance;
        private Button btnUsuarios;
        private Button btnGrupos;
        private Button btnGastos;
        private Button btnReportes;
        private ListBox lstBalances;
        private Button btnGuardarCambios;


        public MainForm()
        {
            InicializarComponentes();
        }

        private void InicializarComponentes()
        {
            this.Text = "Proyecto Gastos";
            this.Width = 470;
            this.Height = 490;

            // Botones y ListBox
            btnCargarDatos = new Button { Text = "Cargar Datos", Left = 10, Top = 10, Width = 100 };
            btnMostrarBalance = new Button { Text = "Mostrar Balance", Left = 320, Top = 10, Width = 120 };
            btnUsuarios = new Button { Text = "Ver Usuarios", Left = 10, Top = 370, Width = 100 };
            btnGrupos = new Button { Text = "Ver Grupos", Left = 120, Top = 370, Width = 100 };
            btnGastos = new Button { Text = "Ver Gastos", Left = 230, Top = 370, Width = 100 };
            btnReportes = new Button { Text = "Reportes", Left = 340, Top = 370, Width = 100 };
            lstBalances = new ListBox { Left = 10, Top = 50, Width = 430, Height = 300 };
            btnGuardarCambios = new Button { Text = "Guardar Cambios", Left = 10, Top = 410, Width = 430 };
            btnGuardarCambios.Click += btnGuardarCambios_Click;
            this.Controls.Add(btnGuardarCambios);

            // Agregar al formulario
            this.Controls.Add(btnCargarDatos);
            this.Controls.Add(btnMostrarBalance);
            this.Controls.Add(btnUsuarios);
            this.Controls.Add(btnGrupos);
            this.Controls.Add(btnGastos);
            this.Controls.Add(btnReportes);
            this.Controls.Add(lstBalances);

            // Asignar eventos
            btnCargarDatos.Click += btnCargarDatos_Click;
            btnMostrarBalance.Click += btnMostrarBalance_Click;
            btnUsuarios.Click += (s, e) => new UsuariosForm(usuarios).Show();
            btnGrupos.Click += (s, e) => new GruposForm(grupos, usuarios).Show();
            btnGastos.Click += (s, e) => new GastosForm(gastos).Show();
            btnReportes.Click += (s, e) => new ReportesForm(gastoController).Show();
        }

        private void btnCargarDatos_Click(object sender, EventArgs e)
        {
            usuarios = DataLoader.CargarUsuariosDesdeJson("Data\\usuarios.json");
            grupos = DataLoader.CargarGruposDesdeJson("Data\\grupos.json");
            gastos = DataLoader.CargarGastosDesdeCsv("Data\\gastos.csv");

            gastoController = new GastoController(gastos);
            MessageBox.Show("Datos cargados correctamente.");
        }
        private void btnMostrarBalance_Click(object sender, EventArgs e)
        {
            if (usuarios != null && gastoController != null)
            {
                lstBalances.Items.Clear();
                foreach (var usuario in usuarios)
                {
                    decimal balance = gastoController.CalcularBalanceUsuario(usuario.Id);
                    lstBalances.Items.Add($"{usuario.Nombre}: ₡{balance:N2}");
                }
            }
        }

        private void btnGuardarCambios_Click(object sender, EventArgs e)
        {
            try
            {
                // Serializa los usuarios
                string jsonUsuarios = Newtonsoft.Json.JsonConvert.SerializeObject(usuarios, Newtonsoft.Json.Formatting.Indented);
                System.IO.File.WriteAllText("Data\\usuarios.json", jsonUsuarios);

                // Serializa los grupos
                string jsonGrupos = Newtonsoft.Json.JsonConvert.SerializeObject(grupos, Newtonsoft.Json.Formatting.Indented);
                System.IO.File.WriteAllText("Data\\grupos.json", jsonGrupos);

                // Guarda los gastos en CSV
                using (var writer = new System.IO.StreamWriter("Data\\gastos.csv"))
                using (var csv = new CsvHelper.CsvWriter(writer, new CsvHelper.Configuration.CsvConfiguration(System.Globalization.CultureInfo.InvariantCulture)
                {
                    Delimiter = ";"
                }))
                {
                    // Encabezados
                    csv.WriteField("Id");
                    csv.WriteField("Nombre");
                    csv.WriteField("Descripcion");
                    csv.WriteField("Enlace");
                    csv.WriteField("Fecha");
                    csv.WriteField("Monto");
                    csv.WriteField("PagadoPor");
                    csv.WriteField("IncluyeA");
                    csv.NextRecord();

                    foreach (var g in gastos)
                    {
                        csv.WriteField(g.Id);
                        csv.WriteField(g.Nombre);
                        csv.WriteField(g.Descripcion);
                        csv.WriteField(g.Enlace);
                        csv.WriteField(g.Fecha.ToString("d/M/yyyy"));
                        csv.WriteField(g.Monto.ToString(System.Globalization.CultureInfo.InvariantCulture));
                        csv.WriteField(g.PagadoPor);
                        csv.WriteField(string.Join("|", g.IncluyeA));
                        csv.NextRecord();
                    }
                }

                MessageBox.Show("Datos guardados correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar los datos: " + ex.Message);
            }
        }

    }
}