﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

public class GruposForm : Form
{
    private ListBox lstGrupos;
    private TextBox txtNuevoGrupo;
    private Button btnAgregarGrupo;
    private ListBox lstMiembrosDisponibles;
    private ListBox lstMiembrosSeleccionados;
    private Button btnAgregarMiembro;
    private Button btnQuitarMiembro;
    private Button btnAplicarCambios;
    private PictureBox picGrupo;

    private List<Grupo> grupos;
    private List<Usuario> usuarios;

    public GruposForm(List<Grupo> grupos, List<Usuario> usuarios)
    {
        this.grupos = grupos;
        this.usuarios = usuarios;

        this.Text = "Grupos";
        this.Width = 710;
        this.Height = 480;

        lstGrupos = new ListBox { Left = 10, Top = 10, Width = 220, Height = 300 };
        txtNuevoGrupo = new TextBox { Left = 10, Top = 320, Width = 200 };
        btnAgregarGrupo = new Button { Text = "Agregar Grupo", Left = 220, Top = 318, Width = 100 };

        lstMiembrosDisponibles = new ListBox { Left = 250, Top = 10, Width = 190, Height = 200 };
        lstMiembrosSeleccionados = new ListBox { Left = 490, Top = 10, Width = 190, Height = 200 };

        btnAgregarMiembro = new Button { Text = ">>", Left = 450, Top = 80, Width = 30 };
        btnQuitarMiembro = new Button { Text = "<<", Left = 450, Top = 120, Width = 30 };

        btnAplicarCambios = new Button { Text = "Aplicar Cambios", Left = 250, Top = 220, Width = 430, Height = 40 };

        picGrupo = new PictureBox
        {
            Left = 400,
            Top = 270,
            Width = 120,
            Height = 120,
            BorderStyle = BorderStyle.FixedSingle,
            SizeMode = PictureBoxSizeMode.Zoom
        };

        // Eventos
        btnAgregarGrupo.Click += BtnAgregarGrupo_Click;
        btnAgregarMiembro.Click += BtnAgregarMiembro_Click;
        btnQuitarMiembro.Click += BtnQuitarMiembro_Click;
        btnAplicarCambios.Click += BtnAplicarCambios_Click;
        lstGrupos.SelectedIndexChanged += LstGrupos_SelectedIndexChanged;

        this.Controls.Add(lstGrupos);
        this.Controls.Add(txtNuevoGrupo);
        this.Controls.Add(btnAgregarGrupo);
        this.Controls.Add(lstMiembrosDisponibles);
        this.Controls.Add(lstMiembrosSeleccionados);
        this.Controls.Add(btnAgregarMiembro);
        this.Controls.Add(btnQuitarMiembro);
        this.Controls.Add(btnAplicarCambios);
        this.Controls.Add(picGrupo);

        CargarGrupos();
    }

    private void CargarGrupos()
    {
        lstGrupos.Items.Clear();
        foreach (var g in grupos)
        {
            lstGrupos.Items.Add($"{g.Nombre} ({g.Miembros?.Count ?? 0} miembros)");
        }
        picGrupo.Image = null;
        lstMiembrosDisponibles.Items.Clear();
        lstMiembrosSeleccionados.Items.Clear();
    }

    private void LstGrupos_SelectedIndexChanged(object sender, EventArgs e)
    {
        int index = lstGrupos.SelectedIndex;
        if (index < 0)
        {
            lstMiembrosSeleccionados.Items.Clear();
            lstMiembrosDisponibles.Items.Clear();
            picGrupo.Image = null;
            return;
        }

        var grupo = grupos[index];

        lstMiembrosSeleccionados.Items.Clear();
        lstMiembrosDisponibles.Items.Clear();

        var miembrosIds = grupo.Miembros ?? new List<string>();

        foreach (var id in miembrosIds)
        {
            var usuario = usuarios.FirstOrDefault(u => u.Id == id);
            if (usuario != null)
                lstMiembrosSeleccionados.Items.Add(usuario.Nombre);
        }

        foreach (var usuario in usuarios)
        {
            if (!miembrosIds.Contains(usuario.Id))
                lstMiembrosDisponibles.Items.Add(usuario.Nombre);
        }

        CargarImagenGrupo(grupo.Imagen);
    }

    private void CargarImagenGrupo(string nombreImagen)
    {
        try
        {
            if (string.IsNullOrEmpty(nombreImagen))
                nombreImagen = "generic.png";

            string rutaImagen = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "img", nombreImagen);

            if (System.IO.File.Exists(rutaImagen))
                picGrupo.Image = Image.FromFile(rutaImagen);
            else
                picGrupo.Image = Image.FromFile(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "img", "generic.png"));
        }
        catch
        {
            picGrupo.Image = null;
        }
    }

    private void BtnAgregarGrupo_Click(object sender, EventArgs e)
    {
        string nombreGrupo = txtNuevoGrupo.Text.Trim();
        if (!string.IsNullOrEmpty(nombreGrupo))
        {
            var nuevoGrupo = new Grupo
            {
                Id = Guid.NewGuid().ToString(),
                Nombre = nombreGrupo,
                Imagen = "generic.png",
                Miembros = new List<string>()
            };
            grupos.Add(nuevoGrupo);
            txtNuevoGrupo.Clear();
            CargarGrupos();
            MessageBox.Show("Grupo creado. Ahora seleccione miembros.");
        }
        else
        {
            MessageBox.Show("Ingrese un nombre válido para el grupo.");
        }
    }

    private void BtnAgregarMiembro_Click(object sender, EventArgs e)
    {
        if (lstMiembrosDisponibles.SelectedItem != null)
        {
            var nombre = lstMiembrosDisponibles.SelectedItem.ToString();
            lstMiembrosSeleccionados.Items.Add(nombre);
            lstMiembrosDisponibles.Items.Remove(nombre);
        }
    }

    private void BtnQuitarMiembro_Click(object sender, EventArgs e)
    {
        if (lstMiembrosSeleccionados.SelectedItem != null)
        {
            var nombre = lstMiembrosSeleccionados.SelectedItem.ToString();
            lstMiembrosDisponibles.Items.Add(nombre);
            lstMiembrosSeleccionados.Items.Remove(nombre);
        }
    }

    private void BtnAplicarCambios_Click(object sender, EventArgs e)
    {
        int index = lstGrupos.SelectedIndex;
        if (index < 0)
        {
            MessageBox.Show("Seleccione un grupo para aplicar cambios.");
            return;
        }

        var grupo = grupos[index];
        var nuevosMiembros = new List<string>();
        foreach (string nombre in lstMiembrosSeleccionados.Items)
        {
            var usuario = usuarios.FirstOrDefault(u => u.Nombre == nombre);
            if (usuario != null)
                nuevosMiembros.Add(usuario.Id);
        }
        grupo.Miembros = nuevosMiembros;

        MessageBox.Show("Miembros del grupo actualizados.");
        CargarGrupos();
        lstGrupos.SelectedIndex = index;
    }
}
