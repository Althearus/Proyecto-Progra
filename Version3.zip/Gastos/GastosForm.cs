﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Gastos.Models;

public partial class GastosForm : Form
{
    private List<Gasto> gastos;
    private List<Usuario> usuarios;
    private List<Grupo> grupos;

    private ListView listView;
    private TextBox txtNombre;
    private TextBox txtDescripcion;
    private DateTimePicker dtpFecha;
    private TextBox txtMonto;
    private ComboBox cboPagadoPor;
    private ComboBox cboGrupo;
    private Button btnAgregarGasto;

    public GastosForm(List<Gasto> gastos, List<Usuario> usuarios, List<Grupo> grupos)
    {
        this.gastos = gastos;
        this.usuarios = usuarios;
        this.grupos = grupos;

        InitializeComponent();
        CargarGastos();
    }

    private void InitializeComponent()
    {
        this.Text = "Lista de Gastos";
        this.Width = 800;
        this.Height = 600;

        listView = new ListView
        {
            View = View.Details,
            FullRowSelect = true,
            GridLines = true,
            Width = 760,
            Height = 350,
            Location = new Point(10, 10)
        };

        listView.Columns.Add("Nombre", 120);
        listView.Columns.Add("Descripción", 180);
        listView.Columns.Add("Fecha", 100);
        listView.Columns.Add("Monto", 80);
        listView.Columns.Add("Pagado Por", 100);
        listView.Columns.Add("Grupo", 100);
        listView.Columns.Add("Incluye A", 160);

        Label lblNombre = new Label { Text = "Nombre:", Location = new Point(10, 380), Width = 80 };
        txtNombre = new TextBox { Location = new Point(100, 375), Width = 200 };

        Label lblDescripcion = new Label { Text = "Descripción:", Location = new Point(10, 410), Width = 80 };
        txtDescripcion = new TextBox { Location = new Point(100, 405), Width = 200 };

        Label lblFecha = new Label { Text = "Fecha:", Location = new Point(320, 380), Width = 50 };
        dtpFecha = new DateTimePicker { Location = new Point(380, 375), Width = 150, Format = DateTimePickerFormat.Short };

        Label lblMonto = new Label { Text = "Monto:", Location = new Point(320, 410), Width = 50 };
        txtMonto = new TextBox { Location = new Point(380, 405), Width = 150 };

        Label lblPagadoPor = new Label { Text = "Pagado Por:", Location = new Point(10, 440), Width = 100 };
        cboPagadoPor = new ComboBox { Location = new Point(120, 435), Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
        cboPagadoPor.SelectedIndexChanged += CboPagadoPor_SelectedIndexChanged;

        Label lblGrupo = new Label { Text = "Grupo:", Location = new Point(10, 470), Width = 100 };
        cboGrupo = new ComboBox { Location = new Point(120, 465), Width = 250, DropDownStyle = ComboBoxStyle.DropDownList };

        btnAgregarGasto = new Button { Text = "Agregar Gasto", Location = new Point(560, 440), Width = 120, Height = 50 };
        btnAgregarGasto.Click += BtnAgregarGasto_Click;

        this.Controls.Add(listView);
        this.Controls.Add(lblNombre);
        this.Controls.Add(txtNombre);
        this.Controls.Add(lblDescripcion);
        this.Controls.Add(txtDescripcion);
        this.Controls.Add(lblFecha);
        this.Controls.Add(dtpFecha);
        this.Controls.Add(lblMonto);
        this.Controls.Add(txtMonto);
        this.Controls.Add(lblPagadoPor);
        this.Controls.Add(cboPagadoPor);
        this.Controls.Add(lblGrupo);
        this.Controls.Add(cboGrupo);
        this.Controls.Add(btnAgregarGasto);
        cboPagadoPor.Items.AddRange(usuarios.Select(u => u.Id).ToArray());
    }

    private void CboPagadoPor_SelectedIndexChanged(object sender, EventArgs e)
    {
        cboGrupo.Items.Clear();
        string usuarioId = cboPagadoPor.SelectedItem?.ToString();
        if (!string.IsNullOrEmpty(usuarioId))
        {
            var gruposUsuario = grupos.Where(g => g.Miembros.Contains(usuarioId)).ToList();
            foreach (var grupo in gruposUsuario)
            {
                cboGrupo.Items.Add(new ComboBoxItem { Text = grupo.Nombre, Value = grupo.Id });
            }
        }
    }

    private void CargarGastos()
    {
        listView.Items.Clear();

        foreach (var gasto in gastos)
        {
            var incluyeA = gasto.IncluyeA != null ? string.Join(", ", gasto.IncluyeA) : "";
            var item = new ListViewItem(new[]
            {
                gasto.Nombre,
                gasto.Descripcion,
                gasto.Fecha.ToShortDateString(),
                "₡" + gasto.Monto.ToString("N2"),
                gasto.PagadoPor,
                gasto.GrupoId,
                incluyeA
            });
            listView.Items.Add(item);
        }
    }

    private void BtnAgregarGasto_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
            string.IsNullOrWhiteSpace(txtMonto.Text) ||
            cboPagadoPor.SelectedItem == null ||
            cboGrupo.SelectedItem == null)
        {
            MessageBox.Show("Por favor, completa todos los campos.");
            return;
        }

        if (!decimal.TryParse(txtMonto.Text, out decimal monto))
        {
            MessageBox.Show("Monto inválido.");
            return;
        }

        string pagadoPor = cboPagadoPor.SelectedItem.ToString();
        var grupoSeleccionado = (ComboBoxItem)cboGrupo.SelectedItem;
        var grupo = grupos.FirstOrDefault(g => g.Id == grupoSeleccionado.Value);

        var nuevoGasto = new Gasto
        {
            Id = Guid.NewGuid().ToString(),
            Nombre = txtNombre.Text.Trim(),
            Descripcion = txtDescripcion.Text.Trim(),
            Fecha = dtpFecha.Value.Date,
            Monto = monto,
            PagadoPor = pagadoPor,
            GrupoId = grupoSeleccionado.Value,
            IncluyeA = grupo?.Miembros ?? new List<string>()
        };

        gastos.Add(nuevoGasto);
        CargarGastos();

        txtNombre.Clear();
        txtDescripcion.Clear();
        txtMonto.Clear();
        cboPagadoPor.SelectedIndex = -1;
        cboGrupo.Items.Clear();

        MessageBox.Show("Gasto agregado correctamente.");
    }

    private class ComboBoxItem
    {
        public string Text { get; set; }
        public string Value { get; set; }

        public override string ToString() => Text;
    }
}





