using System;
using System.Collections.Generic;
using System.Linq;
using Gastos.Models;

public class GastoController
{
    private List<Gasto> gastos;
    private List<Grupo> grupos;

    public GastoController(List<Gasto> gastos, List<Grupo> grupos)
    {
        this.gastos = gastos;
        this.grupos = grupos;
    }

    public List<Gasto> ObtenerTodos() => gastos;

    public List<Gasto> ObtenerPorFecha(DateTime desde, DateTime hasta)
    {
        return gastos.Where(g => g.Fecha >= desde && g.Fecha <= hasta).ToList();
    }

    public decimal CalcularBalanceUsuario(string usuarioId)
    {
        decimal totalPagado = gastos
            .Where(g => g.PagadoPor == usuarioId)
            .Sum(g => g.Monto);

        decimal totalDeuda = gastos
            .Where(g => g.IncluyeA != null && g.IncluyeA.Contains(usuarioId))
            .Sum(g => g.Monto / g.IncluyeA.Count);

        return totalPagado - totalDeuda;
    }

    public decimal CalcularBalanceGrupo(string grupoId)
    {
        return gastos
            .Where(g => g.GrupoId == grupoId)
            .Sum(g => g.Monto);
    }

    public decimal CalcularBalanceUsuarioEnGrupo(string usuarioId, string grupoId)
    {
        var gastosDelGrupo = gastos.Where(g => g.GrupoId == grupoId);

        decimal totalPagado = gastosDelGrupo
            .Where(g => g.PagadoPor == usuarioId)
            .Sum(g => g.Monto);

        decimal totalDeuda = gastosDelGrupo
            .Where(g => g.IncluyeA != null && g.IncluyeA.Contains(usuarioId))
            .Sum(g => g.Monto / g.IncluyeA.Count);

        return totalPagado - totalDeuda;
    }

    public List<Grupo> ObtenerGrupos() => grupos;
}
