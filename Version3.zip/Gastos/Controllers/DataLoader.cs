using Newtonsoft.Json;
using CsvHelper;
using CsvHelper.Configuration;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System;
using Gastos.Models;

public static class DataLoader
{
    public static List<Usuario> CargarUsuariosDesdeJson(string ruta)
    {
        string contenido = File.ReadAllText(ruta);
        return JsonConvert.DeserializeObject<List<Usuario>>(contenido);
    }

    public static List<Grupo> CargarGruposDesdeJson(string ruta)
    {
        string contenido = File.ReadAllText(ruta);
        return JsonConvert.DeserializeObject<List<Grupo>>(contenido);
    }

    public static List<Gasto> CargarGastosDesdeCsv(string ruta)
    {
        var config = new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            Delimiter = ";",
        };

        using (var reader = new StreamReader(ruta))
        using (var csv = new CsvReader(reader, config))
        {
            var registros = csv.GetRecords<TempGasto>().ToList();

            return registros.Select(g => new Gasto
            {
                Id = g.Id,
                Nombre = g.Nombre,
                Descripcion = g.Descripcion,
                Enlace = g.Enlace,
                Fecha = DateTime.ParseExact(g.Fecha, "d/M/yyyy", CultureInfo.InvariantCulture),
                Monto = decimal.Parse(g.Monto, CultureInfo.InvariantCulture),
                PagadoPor = g.PagadoPor,
                IncluyeA = g.IncluyeA?.Split('|').ToList(),
                GrupoId = g.GrupoId
            }).ToList();
        }
    }

    private class TempGasto
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Enlace { get; set; }
        public string Fecha { get; set; }
        public string Monto { get; set; }
        public string PagadoPor { get; set; }
        public string IncluyeA { get; set; }
        public string GrupoId { get; set; }
    }
}