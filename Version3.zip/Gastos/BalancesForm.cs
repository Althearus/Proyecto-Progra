﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Gastos.Models;

public class BalancesForm : Form
{
    private GastoController gastoController;
    private List<Usuario> usuarios;
    private List<Grupo> grupos;

    private ListBox lstUsuariosBalance;
    private ListBox lstGrupos;
    private ListBox lstUsuariosEnGrupo;

    public BalancesForm(GastoController gastoController, List<Usuario> usuarios, List<Grupo> grupos)
    {
        this.gastoController = gastoController;
        this.usuarios = usuarios;
        this.grupos = grupos;

        InitializeComponent();
        CargarUsuariosBalance();
        CargarGrupos();
    }

    private void InitializeComponent()
    {
        this.Text = "Balances";
        this.Width = 530;
        this.Height = 510;

        Label lblUsuarios = new Label { Text = "Balance General por Usuario", Left = 10, Top = 10 };
        lstUsuariosBalance = new ListBox { Left = 20, Top = 40, Width = 480, Height = 100 };

        Label lblGrupos = new Label { Text = "Grupos", Left = 10, Top = 160 };
        lstGrupos = new ListBox { Left = 20, Top = 190, Width = 100, Height = 250 };
        lstGrupos.SelectedIndexChanged += LstGrupos_SelectedIndexChanged;

        Label lblUsuariosGrupo = new Label { Text = "Usuarios en Grupo (con balance)", Left = 140, Top = 160 };
        lstUsuariosEnGrupo = new ListBox { Left = 140, Top = 190, Width = 360, Height = 250 };

        this.Controls.Add(lblUsuarios);
        this.Controls.Add(lstUsuariosBalance);
        this.Controls.Add(lblGrupos);
        this.Controls.Add(lstGrupos);
        this.Controls.Add(lblUsuariosGrupo);
        this.Controls.Add(lstUsuariosEnGrupo);
    }

    private void CargarUsuariosBalance()
    {
        lstUsuariosBalance.Items.Clear();
        foreach (var usuario in usuarios)
        {
            var balance = gastoController.CalcularBalanceUsuario(usuario.Id);
            lstUsuariosBalance.Items.Add($"{usuario.Nombre}: ₡{balance:N2}");
        }
    }

    private void CargarGrupos()
    {
        lstGrupos.Items.Clear();
        foreach (var grupo in grupos)
        {
            lstGrupos.Items.Add(grupo.Nombre);
        }
    }

    private void LstGrupos_SelectedIndexChanged(object sender, EventArgs e)
    {
        lstUsuariosEnGrupo.Items.Clear();

        int index = lstGrupos.SelectedIndex;
        if (index < 0) return;

        var grupo = grupos[index];

        foreach (var usuarioId in grupo.Miembros)
        {
            var usuario = usuarios.FirstOrDefault(u => u.Id == usuarioId);
            if (usuario != null)
            {
                decimal balance = gastoController.CalcularBalanceUsuarioEnGrupo(usuario.Id, grupo.Id);
                lstUsuariosEnGrupo.Items.Add($"{usuario.Nombre}: ₡{balance:N2}");
            }
        }
    }
}
