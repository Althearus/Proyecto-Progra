using System;
using System.Collections.Generic;

namespace Gastos.Models
{
    public class Gasto
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Enlace { get; set; }
        public DateTime Fecha { get; set; }
        public decimal Monto { get; set; }
        public string PagadoPor { get; set; }
        public string GrupoId { get; set; }
        public List<string> IncluyeA { get; set; }
    }
}