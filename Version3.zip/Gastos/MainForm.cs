﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Gastos.Models;
using System.IO;
using Newtonsoft.Json;
using CsvHelper;
using CsvHelper.Configuration;
using System.Globalization;

namespace Gastos
{
    public class MainForm : Form
    {
        private List<Usuario> usuarios;
        private List<Grupo> grupos;
        private List<Gasto> gastos;
        private GastoController gastoController;

        private Button btnCargarDatos;
        private Button btnBalances;
        private Button btnUsuarios;
        private Button btnGrupos;
        private Button btnGastos;
        private Button btnReportes;
        private Button btnGuardarCambios;

        public MainForm()
        {
            InicializarComponentes();
        }

        private void InicializarComponentes()
        {
            this.Text = "Proyecto Gastos";
            this.Width = 470;
            this.Height = 230;

            btnCargarDatos = new Button { Text = "Cargar Datos", Left = 10, Top = 10, Width = 100 };
            btnBalances = new Button { Text = "Balances", Left = 340, Top = 10, Width = 100 };

            btnUsuarios = new Button { Text = "Ver Usuarios", Left = 10, Top = 50, Width = 100 };
            btnGrupos = new Button { Text = "Ver Grupos", Left = 120, Top = 50, Width = 100 };
            btnGastos = new Button { Text = "Ver Gastos", Left = 230, Top = 50, Width = 100 };
            btnReportes = new Button { Text = "Reportes", Left = 340, Top = 50, Width = 100 };

            btnGuardarCambios = new Button { Text = "Guardar Cambios", Left = 10, Top = 90, Width = 430 };

            btnCargarDatos.Click += btnCargarDatos_Click;
            btnGuardarCambios.Click += btnGuardarCambios_Click;

            btnBalances.Click += (s, e) =>
            {
                if (gastoController != null && usuarios != null && grupos != null)
                    new BalancesForm(gastoController, usuarios, grupos).Show();
                else
                    MessageBox.Show("Primero carga los datos.");
            };

            btnUsuarios.Click += (s, e) =>
            {
                if (usuarios != null)
                    new UsuariosForm(usuarios).Show();
                else
                    MessageBox.Show("Primero carga los datos.");
            };

            btnGrupos.Click += (s, e) =>
            {
                if (grupos != null && usuarios != null)
                    new GruposForm(grupos, usuarios).Show();
                else
                    MessageBox.Show("Primero carga los datos.");
            };

            btnGastos.Click += (s, e) =>
            {
                if (gastos != null && usuarios != null && grupos != null)
                    new GastosForm(gastos, usuarios, grupos).Show();
                else
                    MessageBox.Show("Primero carga los datos.");
            };

            btnReportes.Click += (s, e) =>
            {
                if (gastoController != null)
                    new ReportesForm(gastoController).Show();
                else
                    MessageBox.Show("Primero carga los datos.");
            };

            this.Controls.Add(btnCargarDatos);
            this.Controls.Add(btnBalances);
            this.Controls.Add(btnUsuarios);
            this.Controls.Add(btnGrupos);
            this.Controls.Add(btnGastos);
            this.Controls.Add(btnReportes);
            this.Controls.Add(btnGuardarCambios);
        }

        private void btnCargarDatos_Click(object sender, EventArgs e)
        {
            try
            {
                usuarios = DataLoader.CargarUsuariosDesdeJson("Data\\usuarios.json");
                grupos = DataLoader.CargarGruposDesdeJson("Data\\grupos.json");
                gastos = DataLoader.CargarGastosDesdeCsv("Data\\gastos.csv");

                gastoController = new GastoController(gastos, grupos);

                MessageBox.Show("Datos cargados correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message);
            }
        }

        private void btnGuardarCambios_Click(object sender, EventArgs e)
        {
            try
            {
                string jsonUsuarios = JsonConvert.SerializeObject(usuarios, Formatting.Indented);
                File.WriteAllText("Data\\usuarios.json", jsonUsuarios);

                string jsonGrupos = JsonConvert.SerializeObject(grupos, Formatting.Indented);
                File.WriteAllText("Data\\grupos.json", jsonGrupos);

                using (var writer = new StreamWriter("Data\\gastos.csv"))
                using (var csv = new CsvWriter(writer, new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    Delimiter = ";"
                }))
                {
                    csv.WriteField("Id");
                    csv.WriteField("Nombre");
                    csv.WriteField("Descripcion");
                    csv.WriteField("Enlace");
                    csv.WriteField("Fecha");
                    csv.WriteField("Monto");
                    csv.WriteField("PagadoPor");
                    csv.WriteField("IncluyeA");
                    csv.WriteField("GrupoId");
                    csv.NextRecord();

                    foreach (var g in gastos)
                    {
                        csv.WriteField(g.Id);
                        csv.WriteField(g.Nombre);
                        csv.WriteField(g.Descripcion);
                        csv.WriteField(g.Enlace);
                        csv.WriteField(g.Fecha.ToString("d/M/yyyy"));
                        csv.WriteField(g.Monto.ToString(CultureInfo.InvariantCulture));
                        csv.WriteField(g.PagadoPor);
                        csv.WriteField(string.Join("|", g.IncluyeA));
                        csv.WriteField(g.GrupoId);
                        csv.NextRecord();
                    }
                }

                MessageBox.Show("Datos guardados correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar los datos: " + ex.Message);
            }
        }
    }
}

